package android.support.p003v7.widget;

/* renamed from: android.support.v7.widget.WithHint */
public interface WithHint {
    CharSequence getHint();
}
