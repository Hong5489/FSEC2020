package android.support.p003v7.view;

/* renamed from: android.support.v7.view.CollapsibleActionView */
public interface CollapsibleActionView {
    void onActionViewCollapsed();

    void onActionViewExpanded();
}
