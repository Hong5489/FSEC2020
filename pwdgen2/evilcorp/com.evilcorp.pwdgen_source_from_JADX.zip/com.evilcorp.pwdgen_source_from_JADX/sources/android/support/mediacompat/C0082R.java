package android.support.mediacompat;

import com.evilcorp.pwdgen.C0426R;

/* renamed from: android.support.mediacompat.R */
public final class C0082R {

    /* renamed from: android.support.mediacompat.R$attr */
    public static final class attr {
        public static final int font = 2130903182;
        public static final int fontProviderAuthority = 2130903184;
        public static final int fontProviderCerts = 2130903185;
        public static final int fontProviderFetchStrategy = 2130903186;
        public static final int fontProviderFetchTimeout = 2130903187;
        public static final int fontProviderPackage = 2130903188;
        public static final int fontProviderQuery = 2130903189;
        public static final int fontStyle = 2130903190;
        public static final int fontWeight = 2130903191;
    }

    /* renamed from: android.support.mediacompat.R$bool */
    public static final class bool {
        public static final int abc_action_bar_embed_tabs = 2130968576;
    }

    /* renamed from: android.support.mediacompat.R$color */
    public static final class color {
        public static final int notification_action_color_filter = 2131034186;
        public static final int notification_icon_bg_color = 2131034187;
        public static final int notification_material_background_media_default_color = 2131034188;
        public static final int primary_text_default_material_dark = 2131034193;
        public static final int ripple_material_light = 2131034198;
        public static final int secondary_text_default_material_dark = 2131034199;
        public static final int secondary_text_default_material_light = 2131034200;
    }

    /* renamed from: android.support.mediacompat.R$dimen */
    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 2131099722;
        public static final int compat_button_inset_vertical_material = 2131099723;
        public static final int compat_button_padding_horizontal_material = 2131099724;
        public static final int compat_button_padding_vertical_material = 2131099725;
        public static final int compat_control_corner_material = 2131099726;
        public static final int notification_action_icon_size = 2131099781;
        public static final int notification_action_text_size = 2131099782;
        public static final int notification_big_circle_margin = 2131099783;
        public static final int notification_content_margin_start = 2131099784;
        public static final int notification_large_icon_height = 2131099785;
        public static final int notification_large_icon_width = 2131099786;
        public static final int notification_main_column_padding_top = 2131099787;
        public static final int notification_media_narrow_margin = 2131099788;
        public static final int notification_right_icon_size = 2131099789;
        public static final int notification_right_side_padding_top = 2131099790;
        public static final int notification_small_icon_background_padding = 2131099791;
        public static final int notification_small_icon_size_as_large = 2131099792;
        public static final int notification_subtext_size = 2131099793;
        public static final int notification_top_pad = 2131099794;
        public static final int notification_top_pad_large_text = 2131099795;
    }

    /* renamed from: android.support.mediacompat.R$drawable */
    public static final class C0083drawable {
        public static final int notification_action_background = 2131165282;
        public static final int notification_bg = 2131165283;
        public static final int notification_bg_low = 2131165284;
        public static final int notification_bg_low_normal = 2131165285;
        public static final int notification_bg_low_pressed = 2131165286;
        public static final int notification_bg_normal = 2131165287;
        public static final int notification_bg_normal_pressed = 2131165288;
        public static final int notification_icon_background = 2131165289;
        public static final int notification_template_icon_bg = 2131165290;
        public static final int notification_template_icon_low_bg = 2131165291;
        public static final int notification_tile_bg = 2131165292;
        public static final int notify_panel_notification_icon_bg = 2131165293;
    }

    /* renamed from: android.support.mediacompat.R$id */
    public static final class C0084id {
        public static final int action0 = 2131230726;
        public static final int action_container = 2131230734;
        public static final int action_divider = 2131230736;
        public static final int action_image = 2131230737;
        public static final int action_text = 2131230744;
        public static final int actions = 2131230745;
        public static final int async = 2131230751;
        public static final int blocking = 2131230754;
        public static final int cancel_action = 2131230757;
        public static final int chronometer = 2131230762;
        public static final int end_padder = 2131230781;
        public static final int forever = 2131230791;
        public static final int icon = 2131230795;
        public static final int icon_group = 2131230796;
        public static final int info = 2131230799;
        public static final int italic = 2131230800;
        public static final int line1 = 2131230804;
        public static final int line3 = 2131230805;
        public static final int media_actions = 2131230809;
        public static final int normal = 2131230817;
        public static final int notification_background = 2131230818;
        public static final int notification_main_column = 2131230819;
        public static final int notification_main_column_container = 2131230820;
        public static final int right_icon = 2131230830;
        public static final int right_side = 2131230831;
        public static final int status_bar_latest_event_content = 2131230866;
        public static final int tag_transition_group = 2131230871;
        public static final int text = 2131230872;
        public static final int text2 = 2131230873;
        public static final int time = 2131230880;
        public static final int title = 2131230881;
    }

    /* renamed from: android.support.mediacompat.R$integer */
    public static final class integer {
        public static final int cancel_button_image_alpha = 2131296260;
        public static final int status_bar_notification_info_maxnum = 2131296265;
    }

    /* renamed from: android.support.mediacompat.R$layout */
    public static final class layout {
        public static final int notification_action = 2131361834;
        public static final int notification_action_tombstone = 2131361835;
        public static final int notification_media_action = 2131361836;
        public static final int notification_media_cancel_action = 2131361837;
        public static final int notification_template_big_media = 2131361838;
        public static final int notification_template_big_media_custom = 2131361839;
        public static final int notification_template_big_media_narrow = 2131361840;
        public static final int notification_template_big_media_narrow_custom = 2131361841;
        public static final int notification_template_custom_big = 2131361842;
        public static final int notification_template_icon_group = 2131361843;
        public static final int notification_template_lines_media = 2131361844;
        public static final int notification_template_media = 2131361845;
        public static final int notification_template_media_custom = 2131361846;
        public static final int notification_template_part_chronometer = 2131361847;
        public static final int notification_template_part_time = 2131361848;
    }

    /* renamed from: android.support.mediacompat.R$string */
    public static final class string {
        public static final int status_bar_notification_info_overflow = 2131558440;
    }

    /* renamed from: android.support.mediacompat.R$style */
    public static final class style {
        public static final int TextAppearance_Compat_Notification = 2131624185;
        public static final int TextAppearance_Compat_Notification_Info = 2131624186;
        public static final int TextAppearance_Compat_Notification_Info_Media = 2131624187;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131624188;
        public static final int TextAppearance_Compat_Notification_Line2_Media = 2131624189;
        public static final int TextAppearance_Compat_Notification_Media = 2131624190;
        public static final int TextAppearance_Compat_Notification_Time = 2131624191;
        public static final int TextAppearance_Compat_Notification_Time_Media = 2131624192;
        public static final int TextAppearance_Compat_Notification_Title = 2131624193;
        public static final int TextAppearance_Compat_Notification_Title_Media = 2131624194;
        public static final int Widget_Compat_NotificationActionContainer = 2131624311;
        public static final int Widget_Compat_NotificationActionText = 2131624312;
    }

    /* renamed from: android.support.mediacompat.R$styleable */
    public static final class styleable {
        public static final int[] FontFamily = {C0426R.attr.fontProviderAuthority, C0426R.attr.fontProviderCerts, C0426R.attr.fontProviderFetchStrategy, C0426R.attr.fontProviderFetchTimeout, C0426R.attr.fontProviderPackage, C0426R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, C0426R.attr.font, C0426R.attr.fontStyle, C0426R.attr.fontWeight};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_font = 3;
        public static final int FontFamilyFont_fontStyle = 4;
        public static final int FontFamilyFont_fontWeight = 5;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
    }
}
